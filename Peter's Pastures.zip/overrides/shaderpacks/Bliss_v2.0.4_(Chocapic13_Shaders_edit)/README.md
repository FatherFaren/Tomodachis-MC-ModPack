# Bliss
i always loved chocapic's shaders, and how customizeable it was. But i wanted MORE.
i eventually started tweaking the shader, adding settings, breaking stuff, and after a while wanted to impose my own visual style onto the shader.
i wanted to emphasize a varying scene, where the lighting isn't always the same whenever or wherever you are.

# Resourcepack Support (LabPBR and other stuff)
+ Reflectance / F0
+ Smoothness
+ Subsurface Scattering
+ Emissiveness
+ Parallax Occlusion Mapping / POM
+ Normal Mapping
+ Refraction
<img src="https://user-images.githubusercontent.com/122314734/212524271-d6e6b34a-a2e2-4990-b351-c7e33cfd8095.png" width="75%" height="75%">

# Daily Weather 
+ cloudy, slightly cloudy, or clear days
<img src="https://user-images.githubusercontent.com/122314734/212525082-69257101-a45a-4b89-a49c-4f48328be247.png" width="75%" height="75%">

# Biome Specific Atmospherics
+ Some biomes are very foggy with a unique fog color
<img src="https://user-images.githubusercontent.com/122314734/212524750-ae313931-d58f-4b0f-ac37-f14b74f7fc05.png" width="75%" height="75%">

# i will add more stuff one day
nobody knows when, but it's in the future.

**SPECIAL THANKS:**
+ WoMspace, for doing a DOF overhaul
+ Emin, and Gri573, for teaching me how to stop alot of light leaking
+ RRe36, for the ideas to steal
+ Chocapic13, for the whole thing
